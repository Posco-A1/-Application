package com.example.app_popang;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    Button callBtn;
    Socket s;
    PrintWriter writer;
    TextView number;
    int i = 0;
    String mens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_info_img06);

        callBtn = (Button) findViewById(R.id.callBtn);

        onBtnClick();
    }

    public void onBtnClick() {

        callBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                BackGroundTask b1 = new BackGroundTask();
                b1.execute();
            }
        });
    }

    class BackGroundTask extends AsyncTask<String, Void, Void> {

        Handler h = new Handler();
        @Override
        protected Void doInBackground(String... voids) {
            try {
                mens = String.valueOf(i);

                if(s == null){
                    //change it to your IP
                    s = new Socket("192.168.0.15",6000);
                    writer = new PrintWriter(s.getOutputStream());
                    Log.i("i", "CONNECTED");
                }
                writer.write(mens);
                writer.flush();
                //writer.close();
                i = i+1;
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        number.setText(mens);
                    }
                });
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}